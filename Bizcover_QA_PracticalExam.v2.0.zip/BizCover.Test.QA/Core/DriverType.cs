﻿namespace BizCover.Test.QA.Core
{
    public enum DriverType
    {
        Chrome,
        Firefox,
        Ie
    }
}
