﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BizCover.Test.QA
{
    public static class ConfigSettings
    {
        public static string TestCaseURL { get; set; }
        public static string DriverType { get; set; }
    }
}
